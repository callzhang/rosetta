# @stardustai/annotation-client

**English** | [简体中文](README.zh-CN.md)

A React iframe client connecting the standalone annotation workspace to the Rosetta annotation service. It provides annotation, operator configuration, and algorithm configuration views. The rendering engine and sign-in flow run inside the remote iframe.

```tsx
import { configureRosetta, RosettaAnnotation } from '@stardustai/annotation-client';

configureRosetta({
  frameURL: 'https://annotation.example.com/',
  language: 'en-US',
  readResource: readLocalBlobOrSignedURL,
  saveFile: persistGeneratedFile,
});

<RosettaAnnotation
  taskId={task.id}
  input={task.input}
  language={language}
  onSave={saveTask}
  onProtectionSave={saveRecoveryDraft}
/>;
```

`readResource` returns a Blob or signed URL. `saveFile` returns the URL of a generated file. `onSave` receives results, parameters, data index, and a draft, and resolves after persistence finishes.

`OperatorsEditor` and `AlgorithmEditor` return configuration changes through `onInputChange`. The annotation component's ref provides `captureDraft`, `authorizeSave`, `confirmSave`, and `authorizeExport`. Authorization is handled by the iframe service.

## Languages

English is the default. Set `configureRosetta({ language: 'en-US' })`, or pass a `language` prop to an individual annotation component. Without the prop, the client follows its shared i18next instance.

The initial URL contains `lng`; `FrameInput.language` passes the same locale during initialization. Live changes call the optional `FrameEditor.setLanguage` method. They do not call `updateInput`, reconnect the iframe, or reset its active draft. Older services can omit the method and retain their connection.

## Protocol

Comlink uses two MessagePorts. The handshake validates origin, source, a random channel, and the frame instance. Structured cloning supports Blob and Uint8Array. Import protocol types from `@stardustai/annotation-client/protocol`.

## Build

```sh
npm run typecheck
npm test
npm run build
npm run release
```

The build uses TypeScript and Vite and needs the repository's schema-core dependency. `release` writes the public package archive to the standalone workspace's `vendor/` directory.
